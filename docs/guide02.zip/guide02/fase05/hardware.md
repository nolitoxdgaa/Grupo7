## Hardware

En esta sección colocaran el detalle técnico de o los equipos que utilizaron para el desarrollo de todo el ciclo de vida de desarrollo del prototipo de software.

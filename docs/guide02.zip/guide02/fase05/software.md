## Software

Deberán incluir las herramientas utilizadas y desarrolladas en clase desde la planificación, análisis y diseño, así como del lenguaje de desarrollo que uso el equipo para codificar el prototipo de software
entre otras herramientas que hayan investigado y utilizado para el desarrollo de todo el ciclo de vida de desarrollo del prototipo de software.

Deberán detallar las características técnicas del software que hayan utilizado en cada una de las fases del ciclo de vida del desarrollo del prototipo.

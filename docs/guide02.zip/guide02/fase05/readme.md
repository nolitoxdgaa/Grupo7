## Fase 05: Recursos de software y hardware utilizados

- [Software](software.md)
- [Hardware](hardware.md)
  

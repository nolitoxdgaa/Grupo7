## Seguimiento

En esta sección se presenta el seguimiento de la planificación del proyecto de prototipo de software.

Deberán colocar el plan del proyecto de prototipo de software en su versión final explicitando la ejecución real de las actividades con cierre al 24 de noviembre de 2025.

Asimismo, a manera de resumen, deberá precisar aspectos de relevancia que el ED crea pertinente después de haber realizado una evaluación comparando la versión inicial (programado) de la planificación del trabajo
con la versión final (real) de la misma.

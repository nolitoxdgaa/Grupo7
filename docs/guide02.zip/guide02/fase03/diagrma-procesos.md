## Diagrama de procesos

Diagrama de procesos del negocio del prototipo de software. Para ello utilizaran la herramienta Bizagi Modeler.

- Deberán subir la(s) imágenes de los diagramas en formato .png, .jpg
- Se recomienda utilizar resolución de 300 dpi para cada imagen.

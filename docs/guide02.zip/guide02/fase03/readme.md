# Fase 03: Análisis y diseño del prototipo de software

- [Patrón de software](patron.md)
- [Diagrama de procesos](diagrma-procesos.md)
- [Diagrama de casos de uso](casos-uso.md)
- [Modelo conceptual de datos](modelo-conceptual.md)
- [Modelo lógico-físico de datos (Opcional)](modelo-logico-fisico.md)

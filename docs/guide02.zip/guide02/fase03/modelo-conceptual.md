## Modelo conceptual de datos

Para ello, deberá diseñar el Método Entidad-Relación utilizando una herramienta gráfica de su preferencia. Considerar lo siguiente:

- Utilizar los símbolos y gráficos de notación correspondiente al modelo ER
- Debe haber coherencia con los diagramas de caso de uso y éstos a su vez con el diagrama de procesos.
- Generar y subir la imagen en formato .png, .jpg
- Resolución de la imagen de 300 dpi por cada imagen.

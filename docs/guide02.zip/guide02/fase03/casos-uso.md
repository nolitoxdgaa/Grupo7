## Diagrama de casos de uso

Diagramas y documentación de cada uno de los casos de uso. Con respecto a la documentación de los casos de uso, incluirán lo siguiente:
- Además de los datos del encabezado del CU, incluirán flujo principal y reglas de negocio como mínimo.
- Usar la herramienta gráfica de su preferencia
- Mantener la notación UML de los casos de uso (relaciones include y exclude)
- Subir las imagenes en formato .png, .jpg.
- Resolución de 300 dpi para cada imagen.

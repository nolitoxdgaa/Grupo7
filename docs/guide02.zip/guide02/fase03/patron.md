## Patrón de software

Patrón de diseño del software (IDE de desarrollo) / Patrón de la arquitectura del software según corresponda con la naturaleza del proyecto de prototipo de software: Presente un esquema gráfico de su propuesta y explique con un párrafo de 10 líneas aproximadamente su patrón tomando como base la sesión correspondiente a la Semana 06: Patrones de Diseño de Software.

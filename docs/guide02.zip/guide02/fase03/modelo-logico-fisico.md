## Modelo lógico-físico de datos (Opcional):

En caso de que el ED decida trabajar con base de datos, podrá utilizar el motor de base de datos en el que tenga mejor dominio (u otra herramienta de base de datos que el equipo de desarrollo haya investigado). Asimismo, podrán utilizar el MySQL WorkBench para diseñar su modelo lógico y físico de datos
de acuerdo con lo desarrollado en clase.

- Genera y sube la imagen del modelo de datos físico.
- Imagen en formato .png, .jpg
- Resolución de 300 dpi de la imagen.

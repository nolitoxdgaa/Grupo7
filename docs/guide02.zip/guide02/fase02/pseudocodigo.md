## Pseudocódigo de los requisitos de sistema más importantes (Requisitos funcionales mandatorios)

- En esta sección colocarán los pseudocódigos correspondientes a los requisitos funcionales más importantes del software.
- Mínimamente 02 pseudocodigos y máximo 03 pseudoodigos.

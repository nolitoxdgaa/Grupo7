## Requisitos de Usuario

Este apartado ya fue trabajado en la 
[Guía 01 - Sección: Requisitos de Usuario](../../guide01/requisitos/requisitos-usuarios.md#requisitos-de-usuario).

Consulta y reutiliza ese contenido.

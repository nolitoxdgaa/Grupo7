## Descripción detallada de requisitos no funcionales del software

Este apartado ya fue trabajado en la sección "Requisitos no funcionales" de:

[RTM de la Guía 01](../../guide01/requisitos/rtm.md#Especificación-de-requisitos-de-software)

Consulta y reutiliza ese contenido.

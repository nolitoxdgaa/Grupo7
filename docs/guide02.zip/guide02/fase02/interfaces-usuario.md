## Formato de las interfaces de usuario utilizando herramientas Mockups

En esta sección presentaran los diseños de interfaz de usuario que elaboraron utilizando herramientas Mockups. Considerar lo siguiente:

- El uso de la técnica de prototipo usando mockups es mandatorio como parte de las técnicas de recopilación de información.
- Pueden presentar de igual forma: Minimo 02 y Máximo 03 interfaces.
- Pueden subir el archivo de la imagen de la interfaz en formato .png, .jpg

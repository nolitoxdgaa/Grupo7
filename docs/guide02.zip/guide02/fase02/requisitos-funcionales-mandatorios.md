## Descripción detallada de requisitos funcionales mandatorios del software

Este apartado ya fue trabajado en la sección "Requisitos funcionales" de:

[RTM de la Guía 01](../../guide01/requisitos/rtm.md#Especificación-de-requisitos-de-software)

Consulta y reutiliza ese contenido.

## Fase 06: Pruebas del prototipo de software

- [Pruebas de caja negra](caja-negra.md)
- [Reporte de errores](reporte-errores.md)

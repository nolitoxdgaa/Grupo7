## Reporte de errores

El detalle de los errores encontrados serán indicados en el Anexo 2 - “Informe de errores encontrados”:

## Anexo 2: “Informe de errores encontrados”
- ID Defecto
- Descripción del defecto
- Pasos – Pasos detallados junto con capturas de pantalla que evidencien los defectos encontrados
- Fecha del defecto
- Detectado por (Tester)
- Estado del defecto
- Corregido por
- Fecha de cierre
- Prioridad – Relacionada con la urgencia de corregir el defecto.: Alta, Media, Baja, Crítico

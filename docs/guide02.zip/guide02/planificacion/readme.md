# Fase 01: Planificación del prototipo de software:

Colocar el plan inicial del proyecto de prototipo de software utilizando la herramienta ProjectLibre y de acuerdo con los lineamientos descritos en la “GUIA DE APRENDIZAJE PARA LA PLANIFICACIÓN DE UN PROYECTO DE SOFTWARE” desarrollado en clase.

## Instrucciones:

- Colocar una imagen en formato .jpg / .png
- Deseable que la imagen tenga resolución 300 dpi
- También puede incrustar el archivo .pod del cronograma inicial de trabajo


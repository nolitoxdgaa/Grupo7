## Respuesta a la pregunta de investigación

Se responde en forma abierta a la pregunta de investigación formulada en la sección "Lineamientos generales" de la presente guía de aprendizaje:

[Guía 02 — Encabezado](../README.md#guía-02--guia-de-aprendizaje-para-el-desarrollo-e-implementación-de-un-prototipo-de-software)

En cualquier caso (SÍ o NO), el ED deberá explicar su respuesta.

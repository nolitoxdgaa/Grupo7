# Fase 04: Implementación del prototipo de software

- [Módulos](modulos.md)
- [Código fuente](codigo-fuente.md)
- [Clases generadas (Opcional)](clases-generadas.md)
- [Pantallas de interfaz de usuario](pantallas-usuario.md)


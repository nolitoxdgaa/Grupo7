## Módulos

Describir los módulos (rutinas, opciones de menú) que tiene el prototipo de software. Puede hacerlo mediante texto o gráficamente y en el mejor de los casos ambos.

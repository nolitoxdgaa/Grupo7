## Pantallas de interfaz de usuario

En esta sección deberá subir las imágenes de las pantallas de interfaz de usuario del prototipo de software.

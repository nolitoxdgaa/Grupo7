## Clases generadas (Opcional)

Clases o tablas generadas a través de base de datos. En caso haya generado el modelo lógico y físico de datos mediante un motor de base de datos, éste deberá ser incluido
en el acápite "Modelo lógico-físico" de la Fase 03 de la presente guía de aprendizaje.

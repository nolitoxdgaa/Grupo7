## Código fuente

Código fuente de las funciones más importantes del software. Para ello:

- Puede escribirlo en el estilo markdown de GitHub o puede subir la imagen de las rutinas más importantes.
- En caso sea la imagen, deberá ser en formato .png, .jpg y con resolución de 300 dpi.
